import { Center, Decal, useGLTF } from "@react-three/drei";
import { useEffect, useMemo, useState } from "react";
import * as THREE from "three";

export function HoodieModel({
  tshirtColor = "#ffffff",
  designTexture,
  designTextureBack,
  designTextureLeft,
  designTextureRight,
  designTexturePocket,
  designTextureHood,
  onViewChange,
  frontDecalOffset = [0, 0.05, 0],
  backDecalOffset = [0, 0, 0],
  decalScale = 0.6,
  debugApplyToAllMeshes = false,
}) {
  const { nodes } = useGLTF("/3Dmodels/hoodie.glb");
  const [frontTexture, setFrontTexture] = useState(null);
  const [backTexture, setBackTexture] = useState(null);
  const [leftTexture, setLeftTexture] = useState(null);
  const [rightTexture, setRightTexture] = useState(null);
  const [pocketTexture, setPocketTexture] = useState(null);
  const [hoodTexture, setHoodTexture] = useState(null);

  const loadTexture = (src, setter) => {
    if (src) {
      const loader = new THREE.TextureLoader();
      loader.load(src, (tex) => {
        tex.colorSpace = THREE.SRGBColorSpace;
        tex.minFilter = THREE.LinearFilter;
        tex.generateMipmaps = false;
        setter(tex);
      });
    } else {
      setter(null);
    }
  };

  useEffect(() => { loadTexture(designTexture, setFrontTexture); }, [designTexture]);
  useEffect(() => { loadTexture(designTextureBack, setBackTexture); }, [designTextureBack]);
  useEffect(() => { loadTexture(designTextureLeft, setLeftTexture); }, [designTextureLeft]);
  useEffect(() => { loadTexture(designTextureRight, setRightTexture); }, [designTextureRight]);
  useEffect(() => { loadTexture(designTexturePocket, setPocketTexture); }, [designTexturePocket]);
  useEffect(() => { loadTexture(designTextureHood, setHoodTexture); }, [designTextureHood]);

  const meshNodes = useMemo(() => {
    const list = Object.values(nodes).filter((node) => node.type === "Mesh");
    list.forEach((node) => {
      if (node.geometry) {
        node.geometry.computeVertexNormals();
        node.geometry.computeBoundingBox();
      }
    });
    return list;
  }, [nodes]);

  // Identify primary body mesh (largest volume)
  const bodyMesh = useMemo(() => {
    if (meshNodes.length === 0) return null;
    let best = meshNodes[0];
    let bestVolume = -Infinity;

    meshNodes.forEach((node) => {
      const box = node.geometry?.boundingBox;
      if (!box) return;
      const size = new THREE.Vector3();
      box.getSize(size);
      const volume = size.x * size.y * size.z;
      if (volume > bestVolume) {
        bestVolume = volume;
        best = node;
      }
    });
    return best;
  }, [meshNodes]);

  const decalPlacement = useMemo(() => {
    if (!bodyMesh?.geometry?.boundingBox) return null;

    const box = bodyMesh.geometry.boundingBox;
    const size = new THREE.Vector3();
    const center = new THREE.Vector3();
    box.getSize(size);
    box.getCenter(center);

    const chestY = box.min.y + size.y * 0.55;
    const frontZ = box.max.z - size.z * 0.1;
    const backZ = box.min.z + size.z * 0.1;
    const baseScale = Math.min(size.x, size.y) * decalScale;
    const depth = size.z * 0.6 || 0.15;

    return {
      front: {
        position: [
          center.x + frontDecalOffset[0],
          chestY + frontDecalOffset[1],
          frontZ + frontDecalOffset[2],
        ],
        rotation: [0, 0, 0],
        scale: [baseScale * 1.5, baseScale * 1.5, depth],
      },
      back: {
        position: [
          center.x + backDecalOffset[0],
          chestY + backDecalOffset[1],
          backZ + backDecalOffset[2],
        ],
        rotation: [0, Math.PI, 0],
        scale: [baseScale * 1.65, baseScale * 1.65, depth],
      },
    };
  }, [bodyMesh, decalScale, frontDecalOffset, backDecalOffset]);

  const handleClick = (view) => {
    onViewChange?.(view);
  };

  return (
    <Center position={[0, -3.9, 0]}>
      <group dispose={null} scale={10.5}>
        {meshNodes.map((node, index) => {
          const isBodyMesh = node === bodyMesh;

          // Determine mesh parts by local coordinates
          const box = node.geometry?.boundingBox;
          const center = new THREE.Vector3();
          if (box) box.getCenter(center);

          const isLeftSleeve = !isBodyMesh && center.x < -0.6;
          const isRightSleeve = !isBodyMesh && center.x > 0.6;
          const isHood = !isBodyMesh && center.y > 0.8;
          const isPocket = !isBodyMesh && center.y < -0.3 && center.z > 0.3;

          return (
            <mesh key={index} geometry={node.geometry} castShadow receiveShadow>
              <meshStandardMaterial
                color={tshirtColor}
                side={THREE.DoubleSide}
                roughness={0.9}
                metalness={0}
              />

              {/* Body Front Decal */}
              {frontTexture && decalPlacement && (
                <Decal
                  position={decalPlacement.front.position}
                  rotation={decalPlacement.front.rotation}
                  scale={decalPlacement.front.scale}
                  onClick={() => handleClick("front")}
                >
                  <meshStandardMaterial
                    map={frontTexture}
                    transparent
                    polygonOffset
                    polygonOffsetFactor={-10}
                  />
                </Decal>
              )}

              {/* Body Back Decal */}
              {backTexture && decalPlacement && (
                <Decal
                  position={decalPlacement.back.position}
                  rotation={decalPlacement.back.rotation}
                  scale={decalPlacement.back.scale}
                  onClick={() => handleClick("back")}
                >
                  <meshStandardMaterial
                    map={backTexture}
                    transparent
                    polygonOffset
                    polygonOffsetFactor={-10}
                  />
                </Decal>
              )}

              {/* Left Sleeve Decal */}
              {isLeftSleeve && leftTexture && (
                <Decal
                  position={[center.x + 0.05, center.y - 0.2, center.z + 0.1]}
                  rotation={[0, -Math.PI / 4, 0]}
                  scale={[0.3, 0.6, 0.3]}
                  onClick={() => handleClick("left")}
                >
                  <meshStandardMaterial
                    map={leftTexture}
                    transparent
                    polygonOffset
                    polygonOffsetFactor={-10}
                  />
                </Decal>
              )}

              {/* Right Sleeve Decal */}
              {isRightSleeve && rightTexture && (
                <Decal
                  position={[center.x - 0.05, center.y - 0.2, center.z + 0.1]}
                  rotation={[0, Math.PI / 4, 0]}
                  scale={[0.3, 0.6, 0.3]}
                  onClick={() => handleClick("right")}
                >
                  <meshStandardMaterial
                    map={rightTexture}
                    transparent
                    polygonOffset
                    polygonOffsetFactor={-10}
                  />
                </Decal>
              )}

              {/* Hood Decal */}
              {isHood && hoodTexture && (
                <Decal
                  position={[center.x, center.y, center.z + 0.1]}
                  rotation={[0, 0, 0]}
                  scale={[0.4, 0.4, 0.4]}
                  onClick={() => handleClick("hood")}
                >
                  <meshStandardMaterial
                    map={hoodTexture}
                    transparent
                    polygonOffset
                    polygonOffsetFactor={-10}
                  />
                </Decal>
              )}

              {/* Pocket Decal */}
              {isPocket && pocketTexture && (
                <Decal
                  position={[center.x, center.y, center.z + 0.05]}
                  rotation={[0, 0, 0]}
                  scale={[0.5, 0.3, 0.1]}
                  onClick={() => handleClick("pocket")}
                >
                  <meshStandardMaterial
                    map={pocketTexture}
                    transparent
                    polygonOffset
                    polygonOffsetFactor={-10}
                  />
                </Decal>
              )}
            </mesh>
          );
        })}
      </group>
    </Center>
  );
}

useGLTF.preload("/3Dmodels/hoodie.glb");