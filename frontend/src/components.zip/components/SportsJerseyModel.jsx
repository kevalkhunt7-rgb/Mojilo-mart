import { Center, Decal, useGLTF } from "@react-three/drei";
import { useEffect, useRef, useState, useMemo } from "react";
import * as THREE from "three";

export function SportsJerseyModel({
  tshirtColor = "#ffffff",
  designTexture,
  designTextureBack,
  designTextureLeft,
  designTextureRight,
  playerName = "",
  playerNumber = "",
  sponsorLogo = null,
  onViewChange,
}) {
  const { nodes, materials } = useGLTF("/3Dmodels/02.glb");
  
  const [frontTexture, setFrontTexture] = useState(null);
  const [backTexture, setBackTexture] = useState(null);
  const [leftTexture, setLeftTexture] = useState(null);
  const [rightTexture, setRightTexture] = useState(null);
  const [jerseyTextTexture, setJerseyTextTexture] = useState(null);
  const [sponsorTexture, setSponsorTexture] = useState(null);
  
  const meshRef = useRef();

  const loadTexture = (src, setter) => {
    if (src) {
      const loader = new THREE.TextureLoader();
      loader.load(src, (tex) => {
        tex.colorSpace = THREE.SRGBColorSpace;
        tex.minFilter = THREE.LinearFilter;
        tex.generateMipmaps = false;
        setter(tex);
      });
    } else {
      setter(null);
    }
  };

  useEffect(() => { loadTexture(designTexture, setFrontTexture); }, [designTexture]);
  useEffect(() => { loadTexture(designTextureBack, setBackTexture); }, [designTextureBack]);
  useEffect(() => { loadTexture(designTextureLeft, setLeftTexture); }, [designTextureLeft]);
  useEffect(() => { loadTexture(designTextureRight, setRightTexture); }, [designTextureRight]);
  useEffect(() => { loadTexture(sponsorLogo, setSponsorTexture); }, [sponsorLogo]);

  // Generate real-time text decal for name & number
  useEffect(() => {
    if (!playerName && !playerNumber) {
      setJerseyTextTexture(null);
      return;
    }

    const canvas = document.createElement("canvas");
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext("2d");

    ctx.clearRect(0, 0, 512, 512);

    // Draw Name
    if (playerName) {
      ctx.font = "bold 52px Impact, sans-serif";
      ctx.fillStyle = "#ffffff";
      ctx.strokeStyle = "#000000";
      ctx.lineWidth = 8;
      ctx.textAlign = "center";
      ctx.strokeText(playerName.toUpperCase(), 256, 120);
      ctx.fillText(playerName.toUpperCase(), 256, 120);
    }

    // Draw Number
    if (playerNumber) {
      ctx.font = "bold 220px Impact, sans-serif";
      ctx.fillStyle = "#ffffff";
      ctx.strokeStyle = "#000000";
      ctx.lineWidth = 16;
      ctx.textAlign = "center";
      ctx.strokeText(playerNumber, 256, 340);
      ctx.fillText(playerNumber, 256, 340);
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.minFilter = THREE.LinearFilter;
    texture.generateMipmaps = false;
    setJerseyTextTexture(texture);

    return () => {
      texture.dispose();
    };
  }, [playerName, playerNumber]);

  useEffect(() => {
    if (meshRef.current) {
      meshRef.current.material.color.set(tshirtColor);
    }
  }, [tshirtColor]);

  const handleClick = (view) => {
    onViewChange?.(view);
  };

  return (
    <Center position={[0, 0.5, 0]}>
      <group dispose={null}>
        <group rotation={[Math.PI / 2, 0, 0]}>
          
          {/* Main jersey background body */}
          <mesh
            scale={13}
            position={[0, 0, 2]}
            castShadow
            receiveShadow
            geometry={nodes["T-Shirt_1"].geometry}
            material={materials.Shirt}
          />

          {/* Front view chest mesh and decals */}
          <mesh
            castShadow
            receiveShadow
            geometry={nodes["T-Shirt_2"].geometry}
            scale={13}
            position={[0, 0, 2]}
            material={materials["front.001"]}
          >
            <meshBasicMaterial transparent opacity={0} />
            
            {frontTexture && (
              <Decal
                position={[0, 0.2, -0.31]}
                rotation={[-Math.PI / 2 - 0.05, 0, 0]}
                scale={[0.52, 0.7, 0.5]}
                onClick={() => handleClick("front")}
              >
                <meshStandardMaterial
                  map={frontTexture}
                  toneMapped={false}
                  transparent
                  polygonOffset
                  polygonOffsetFactor={-1}
                />
              </Decal>
            )}

            {sponsorTexture && (
              <Decal
                position={[0, 0.05, -0.31]}
                rotation={[-Math.PI / 2 - 0.05, 0, 0]}
                scale={[0.25, 0.15, 0.5]}
              >
                <meshStandardMaterial
                  map={sponsorTexture}
                  toneMapped={false}
                  transparent
                  polygonOffset
                  polygonOffsetFactor={-2}
                />
              </Decal>
            )}
          </mesh>

          {/* Back view mesh and decals */}
          <mesh
            castShadow
            receiveShadow
            geometry={nodes["T-Shirt_3"].geometry}
            material={materials.back}
            scale={13}
            position={[0, 0, 2]}
          >
            <meshBasicMaterial transparent opacity={0} />
            
            {backTexture && (
              <Decal
                position={[0, -0.2, -0.27]}
                rotation={[Math.PI / 2 - 0.2, 0, Math.PI]}
                scale={[0.52, 0.7, 0.5]}
                onClick={() => handleClick("back")}
              >
                <meshStandardMaterial
                  map={backTexture}
                  toneMapped={false}
                  transparent
                  polygonOffset
                  polygonOffsetFactor={-1}
                />
              </Decal>
            )}

            {/* Dynamic Player Details Overlay */}
            {jerseyTextTexture && (
              <Decal
                position={[0, -0.15, -0.27]}
                rotation={[Math.PI / 2 - 0.2, 0, Math.PI]}
                scale={[0.42, 0.42, 0.5]}
              >
                <meshStandardMaterial
                  map={jerseyTextTexture}
                  toneMapped={false}
                  transparent
                  polygonOffset
                  polygonOffsetFactor={-2}
                />
              </Decal>
            )}
          </mesh>

          {/* Left sleeve mesh and decals */}
          <mesh
            castShadow
            receiveShadow
            geometry={nodes["T-Shirt_4"].geometry}
            material={materials["left hand"]}
            scale={13}
            position={[0, 0, 2]}
          >
            <meshBasicMaterial transparent opacity={0} />
            
            {leftTexture && (
              <Decal
                position={[-0.45, 0.28, -0.25]}
                rotation={[-Math.PI / 2, -Math.PI / 4, 0]}
                scale={[0.2, 0.35, 0.2]}
                onClick={() => handleClick("left")}
              >
                <meshStandardMaterial
                  map={leftTexture}
                  transparent
                  polygonOffset
                  polygonOffsetFactor={-2}
                />
              </Decal>
            )}
          </mesh>

          {/* Right sleeve mesh and decals */}
          <mesh
            castShadow
            receiveShadow
            geometry={nodes["T-Shirt_5"].geometry}
            material={materials["right hand"]}
            scale={13}
            position={[0, 0, 2]}
          >
            <meshBasicMaterial transparent opacity={0} />

            {rightTexture && (
              <Decal
                position={[0.45, 0.28, -0.25]}
                rotation={[-Math.PI / 2, Math.PI / 4, 0]}
                scale={[0.2, 0.35, 0.2]}
                onClick={() => handleClick("right")}
              >
                <meshStandardMaterial
                  map={rightTexture}
                  transparent
                  polygonOffset
                  polygonOffsetFactor={-2}
                />
              </Decal>
            )}
          </mesh>

        </group>
        
        {/* Shadow / garment tone mesh wrapper */}
        <group rotation={[Math.PI / 2, 0, 0]}>
          <mesh
            castShadow
            receiveShadow
            geometry={nodes["T-Shirt001"].geometry}
            material={materials.background}
            scale={13}
            position={[0, 0, 2]}
            ref={meshRef}
          />
        </group>

      </group>
    </Center>
  );
}

useGLTF.preload("/3Dmodels/02.glb");
