import React from "react";
import { Info, Calculator, Tag, Sparkles, Image as ImageIcon, Type, Layers } from "lucide-react";
import { useCustomizerStore } from "../store/useCustomizerStore";

export default function PriceCalculator() {
  const pricingDetails = useCustomizerStore((state) => state.pricingDetails);

  return (
    <div className="bg-white rounded-xl border border-slate-200/80 shadow-sm p-4 w-full">
      <div className="flex items-center gap-1.5 border-b border-slate-100 pb-3 mb-3">
        <Calculator className="h-4.5 w-4.5 text-slate-800" />
        <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Price Estimation</h4>
      </div>

      {/* Breakdowns Grid */}
      <div className="space-y-2 text-xs">
        
        {/* Base Price */}
        <div className="flex items-center justify-between text-slate-600">
          <span className="flex items-center gap-1">
            <Tag className="h-3.5 w-3.5 text-slate-400" />
            Base Garment
          </span>
          <span className="font-semibold text-slate-800">₹{pricingDetails.base.toFixed(2)}</span>
        </div>

        {/* Text Elements */}
        {pricingDetails.text > 0 && (
          <div className="flex items-center justify-between text-slate-600">
            <span className="flex items-center gap-1">
              <Type className="h-3.5 w-3.5 text-slate-400" />
              Text Layers
            </span>
            <span className="font-semibold text-slate-800">+ ₹{pricingDetails.text.toFixed(2)}</span>
          </div>
        )}

        {/* Uploaded Images */}
        {pricingDetails.image > 0 && (
          <div className="flex items-center justify-between text-slate-600">
            <span className="flex items-center gap-1">
              <ImageIcon className="h-3.5 w-3.5 text-slate-400" />
              Uploaded Graphics
            </span>
            <span className="font-semibold text-slate-800">+ ₹{pricingDetails.image.toFixed(2)}</span>
          </div>
        )}

        {/* AI Images */}
        {pricingDetails.ai > 0 && (
          <div className="flex items-center justify-between text-slate-600">
            <span className="flex items-center gap-1">
              <Sparkles className="h-3.5 w-3.5 text-slate-400" />
              AI Artworks
            </span>
            <span className="font-semibold text-slate-800">+ ₹{pricingDetails.ai.toFixed(2)}</span>
          </div>
        )}

        {/* Print Area Size Charge */}
        {pricingDetails.area > 0 && (
          <div className="flex items-center justify-between text-slate-600">
            <span className="flex items-center gap-1">
              <Layers className="h-3.5 w-3.5 text-slate-400" />
              Ink Coverage Area
            </span>
            <span className="font-semibold text-slate-800">+ ₹{pricingDetails.area.toFixed(2)}</span>
          </div>
        )}

        {/* Extra Sides (Sleeves / Hood / Pocket / Back) */}
        {pricingDetails.extra > 0 && (
          <div className="flex items-center justify-between text-slate-600">
            <span className="flex items-center gap-1">
              <Layers className="h-3.5 w-3.5 text-slate-400" />
              Extra Placements
            </span>
            <span className="font-semibold text-slate-800">+ ₹{pricingDetails.extra.toFixed(2)}</span>
          </div>
        )}

        {/* Total Price */}
        <div className="flex items-center justify-between border-t border-slate-100 pt-3 mt-3">
          <span className="text-sm font-bold text-slate-900">Total Price</span>
          <span className="text-base font-extrabold text-violet-600">₹{pricingDetails.total.toFixed(2)}</span>
        </div>
      </div>

      {/* Falling estimate disclaimer */}
      <div className="mt-3.5 p-2 bg-slate-50 border border-slate-100 rounded-lg flex items-start gap-1.5">
        <Info className="h-3.5 w-3.5 text-slate-400 shrink-0 mt-0.5" />
        <p className="text-[10px] text-slate-400 leading-normal">
          This price is an estimate based on graphic layers and surface dimensions. Final price is confirmed in cart checkout.
        </p>
      </div>
    </div>
  );
}
