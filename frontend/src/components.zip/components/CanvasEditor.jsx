import React, { useEffect, useRef, useState } from "react";
import * as fabric from "fabric";
import { useCanvas } from "../context/CanvasContext";
import { useCustomizerStore } from "../store/useCustomizerStore";
import { apparelConfig } from "../utils/apparelConfig";
import canvasStorageManager from "../utils/canvasStorageManager";
import { canvasSyncManager } from "../utils/canvasSyncManager";
import { Grid, Maximize, ZoomIn, ZoomOut, Compass } from "lucide-react";

// ---------------------------------------------------------------------------
// IMPORTANT — read this if the print-area box (or center guides) shows up
// in the live 3D preview / exported print file:
//
// Fabric's `excludeFromExport: true` (set on printAreaBox and the
// center-alignment guide lines below) ONLY excludes an object from
// `canvas.toJSON()` / `canvas.toObject()` — i.e. the serialized design
// DATA. It does NOT exclude the object from `canvas.toDataURL()` /
// `canvas.toBlob()`, which rasterize exactly what's currently rendered on
// screen. If your live preview or print-export pipeline grabs a snapshot
// via toDataURL/toBlob (the standard way to texture a 3D mockup or produce
// a print file), the amber guide box WILL be baked into that image even
// though excludeFromExport is set — that flag alone can't hide it there.
//
// Fix: wherever that snapshot is taken, hide guide objects immediately
// before capturing, then restore them. Use this helper:
//
//   import { withGuidesHidden } from "./CanvasEditor";
//   const dataUrl = withGuidesHidden(fabricCanvas, () =>
//     fabricCanvas.toDataURL({ format: "png" })
//   );
//
export function withGuidesHidden(canvas, captureFn) {
  if (!canvas) {
    console.warn("withGuidesHidden: Canvas not available");
    return null;
  }
  
  // Check if canvas is fully initialized
  if (!canvas.getObjects) {
    console.warn("withGuidesHidden: Canvas not fully initialized");
    return null;
  }
  
  const guides = canvas.getObjects().filter((o) => o.excludeFromExport);
  guides.forEach((o) => o.set("visible", false));
  
  try {
    if (canvas.requestRenderAll) {
      canvas.requestRenderAll();
    }
    return captureFn();
  } finally {
    guides.forEach((o) => o.set("visible", true));
    if (canvas.requestRenderAll) {
      canvas.requestRenderAll();
    }
  }
}

// ---------------------------------------------------------------------------
// Garment silhouette overlay — uses actual product SVG art from /assets
// ---------------------------------------------------------------------------
import tshirtFrontSvg from "../assets/tshirt_front.svg";
import tshirtBackSvg from "../assets/tshirt_back.svg";
import longSleeveFrontSvg from "../assets/long-sleeve-front.svg";
import longSleeveBackSvg from "../assets/long-sleeve-back.svg";
import hoodieFrontSvg from "../assets/hoodie_front.svg";
import hoodieBackSvg from "../assets/hoodie_back.svg";
import oversizedFrontSvg from "../assets/oversized_front.svg";
import oversizedBackSvg from "../assets/oversize-back.svg";

// Map each product + view combination to the right SVG asset.
const GARMENT_SVGS = {
  "half-sleeve": { front: tshirtFrontSvg, back: tshirtBackSvg },
  "long-sleeve": { front: longSleeveFrontSvg, back: longSleeveBackSvg, left: longSleeveFrontSvg, right: longSleeveFrontSvg },
  "hoodie":      { front: hoodieFrontSvg, back: hoodieBackSvg, left: hoodieFrontSvg, right: hoodieFrontSvg, pocket: hoodieFrontSvg, hood: hoodieFrontSvg },
  "oversized":   { front: oversizedFrontSvg, back: oversizedBackSvg },
  "sports-jersey": { front: tshirtFrontSvg, back: tshirtBackSvg, left: tshirtFrontSvg, right: tshirtFrontSvg },
};

function getGarmentSvg(product, view) {
  const productSvgs = GARMENT_SVGS[product] || GARMENT_SVGS["half-sleeve"];
  const v = (view || "").toLowerCase();
  if (v === "back") return productSvgs.back;
  return productSvgs.front;
}

function GarmentSilhouette({ product, view, width, height }) {
  const svgSrc = getGarmentSvg(product, view);

  return (
    <div
      className="absolute inset-0 z-[2] pointer-events-none flex items-center justify-center"
      style={{ width, height }}
      aria-hidden="true"
    >
      <img
        src={svgSrc}
        alt=""
        className="w-full h-full object-contain opacity-[0.3] select-none"
        draggable={false}
      />
    </div>
  );
}

// Ticks ruler component drawing inches (50px = 1 inch)
function CanvasRuler({ orientation, length, zoom }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    
    // Support Retina screens
    const ratio = window.devicePixelRatio || 1;
    if (orientation === "horizontal") {
      canvas.width = length * ratio;
      canvas.height = 24 * ratio;
      canvas.style.width = `${length}px`;
      canvas.style.height = `24px`;
    } else {
      canvas.width = 24 * ratio;
      canvas.height = length * ratio;
      canvas.style.width = `24px`;
      canvas.style.height = `${length}px`;
    }
    
    ctx.scale(ratio, ratio);
    ctx.clearRect(0, 0, length, 24);
    ctx.strokeStyle = "#94a3b8"; // slate-400
    ctx.fillStyle = "#64748b"; // slate-500
    ctx.font = "9px sans-serif";
    ctx.lineWidth = 1;

    const inchPx = 50; // 50px = 1 inch
    const divisions = 5; // Ticks every 10px (0.2 inch)

    if (orientation === "horizontal") {
      ctx.beginPath();
      ctx.moveTo(0, 23);
      ctx.lineTo(length, 23);
      ctx.stroke();

      for (let i = 0; i <= length; i += inchPx / divisions) {
        const isInch = i % inchPx === 0;
        const tickHeight = isInch ? 14 : i % (inchPx / 2) === 0 ? 8 : 4;
        
        ctx.beginPath();
        ctx.moveTo(i, 24 - tickHeight);
        ctx.lineTo(i, 23);
        ctx.stroke();

        if (isInch && i > 0) {
          const val = i / inchPx;
          ctx.fillText(`${val}"`, i + 3, 11);
        }
      }
    } else {
      ctx.beginPath();
      ctx.moveTo(23, 0);
      ctx.lineTo(23, length);
      ctx.stroke();

      for (let i = 0; i <= length; i += inchPx / divisions) {
        const isInch = i % inchPx === 0;
        const tickWidth = isInch ? 14 : i % (inchPx / 2) === 0 ? 8 : 4;

        ctx.beginPath();
        ctx.moveTo(24 - tickWidth, i);
        ctx.lineTo(23, i);
        ctx.stroke();

        if (isInch && i > 0) {
          const val = i / inchPx;
          ctx.save();
          ctx.translate(10, i + 3);
          ctx.rotate(-Math.PI / 2);
          ctx.fillText(`${val}"`, 0, 0);
          ctx.restore();
        }
      }
    }
  }, [orientation, length, zoom]);

  return <canvas ref={canvasRef} className="bg-slate-100" />;
}

// Single active canvas editor viewport wrapper
function SingleCanvasViewport({ view, printArea, manualSync, isSelected, currentProduct }) {
  const canvasRef = useRef(null);
  const containerRef = useRef(null);
  const fabricCanvasRef = useRef(null);
  const { 
    setFrontCanvas, 
    setBackCanvas, 
    setLeftCanvas, 
    setRightCanvas, 
    setPocketCanvas, 
    setHoodCanvas,
    setActiveCanvas, 
    setSelectedObject 
  } = useCanvas();

  const gridVisible = useCustomizerStore((state) => state.gridVisible);
  const rulersVisible = useCustomizerStore((state) => state.rulersVisible);
  const canvasZoom = useCustomizerStore((state) => state.canvasZoom);
  const recalculatePrice = useCustomizerStore((state) => state.recalculatePrice);
  const pushSnapshot = useCustomizerStore((state) => state.pushSnapshot);

  // Pad canvas size by 50px around the print area box
  const padding = 50;
  const canvasWidth = printArea.width + padding * 2;
  const canvasHeight = printArea.height + padding * 2;

  // The printable/design region uses 80% of the print area's dimensions
 const boxWidth = Math.floor(printArea.width * 0.8);
  const boxHeight = Math.floor(printArea.height * 0.8);
  
  // Force it to be a perfect square by choosing the smaller side
  const boxSize = Math.min(boxWidth, boxHeight);

  // Center the perfect square inside the print area
  const boxLeft = padding + (printArea.width - boxSize) / 2;
  const boxTop = padding + (printArea.height - boxSize) / 2;
  // Diagnostic: if this box still looks elongated in the browser after
  // this fix, open devtools and check this log. printArea.width/height
  // come straight from apparelConfig — if one of those two numbers is
  // much larger than the other, boxSize (their min) is still a square,
  // but it's worth confirming these are the values you expect for this
  // product/view. If boxSize itself looks wrong, the issue is in
  // apparelConfig's printAreas, not here.
  if (process.env.NODE_ENV !== "production") {
    console.debug(
      `[CanvasEditor:${view}] printArea=${printArea.width}x${printArea.height} -> boxSize=${boxSize} (left:${boxLeft}, top:${boxTop})`
    );
  }

  // Sync pricing & history
  const updateGlobalStatus = () => {
    if (!fabricCanvasRef.current) return;
    const canvasesData = {};
    const views = ["front", "back", "left", "right", "pocket", "hood"];
    
    // Fetch objects for all active canvases in the context
    // In our app, we load from current memory store
    const frontObjects = window.frontCanvas?.getObjects().map(o => o.toJSON()) || [];
    // ...
  };

  useEffect(() => {
    if (!canvasRef.current) return;

    // Dispose any existing Fabric instance on this <canvas> element before
    // re-initialising. This is required in React 18 Strict Mode which
    // double-fires effects, and also handles hot-reload / view switching.
    if (fabricCanvasRef.current) {
      try { fabricCanvasRef.current.dispose(); } catch (_) {}
      fabricCanvasRef.current = null;
    }

    // Initialize Fabric
    const canvas = new fabric.Canvas(canvasRef.current, {
      width: canvasWidth,
      height: canvasHeight,
      backgroundColor: "transparent",
      preserveObjectStacking: true,
    });

    fabricCanvasRef.current = canvas;

    // Register to canvas context
    if (view === "front") setFrontCanvas(canvas);
    if (view === "back") setBackCanvas(canvas);
    if (view === "left") setLeftCanvas(canvas);
    if (view === "right") setRightCanvas(canvas);
    if (view === "pocket") setPocketCanvas(canvas);
    if (view === "hood") setHoodCanvas(canvas);

    // NOTE: we deliberately do NOT call setActiveCanvas(canvas) here.
    // All view canvases mount at once (they're only hidden via CSS, not
    // unmounted), so calling it unconditionally on init meant whichever
    // view's effect happened to run last silently became "active" —
    // regardless of which tab the user had selected. This caused
    // uploads/text to always land on one fixed view (e.g. back) no
    // matter what was showing. Active-canvas registration now happens
    // in the dedicated `isSelected` effect below instead.

    // Render print area dotted outline box
    const printAreaBox = new fabric.Rect({
      left: boxLeft,
      top: boxTop,
      width: boxWidth,
      height: boxHeight,
      fill: "transparent",
      stroke: "transparent", // Amber outline removed visually
      strokeWidth: 0,
      selectable: false,
      evented: false,
      excludeFromExport: true,
      visible: false, // Ensure it's not rendered
    });

    canvas.add(printAreaBox);
    // Fabric v6: sendToBack() is now sendObjectToBack()
    canvas.sendObjectToBack(printAreaBox);

    // Boundary constraint logic (Restrict to the printable box)
    const clampPosition = (obj) => {
      const width = obj.getScaledWidth();
      const height = obj.getScaledHeight();

      let minX = boxLeft;
      let maxX = boxLeft + boxWidth - width;
      let minY = boxTop;
      let maxY = boxTop + boxHeight - height;

      if (obj.originX === "center") {
        minX += width / 2;
        maxX += width / 2;
      }
      if (obj.originY === "center") {
        minY += height / 2;
        maxY += height / 2;
      }

      if (obj.left < minX) obj.left = minX;
      if (obj.left > maxX) obj.left = maxX;
      if (obj.top < minY) obj.top = minY;
      if (obj.top > maxY) obj.top = maxY;
    };

    const handleObjectMoving = (e) => {
      const obj = e.target;
      if (!obj || obj === printAreaBox) return;
      
      // If active selection (multiple items selected), loop through elements
      if (obj.type === "activeSelection") {
        obj.getObjects().forEach((subObj) => {
          clampPosition(subObj);
        });
      } else {
        clampPosition(obj);
      }
    };

    // Shared helper: shrink an object to fit inside the box (if it's
    // larger than it) and clamp its position.
    const constrainToBox = (obj) => {
      const width = obj.getScaledWidth();
      const height = obj.getScaledHeight();

      if (width > boxWidth) {
        obj.scaleX = boxWidth / obj.width;
      }
      if (height > boxHeight) {
        obj.scaleY = boxHeight / obj.height;
      }

      clampPosition(obj);
    };

    const handleObjectScaling = (e) => {
      const obj = e.target;
      if (!obj || obj === printAreaBox) return;
      constrainToBox(obj);
    };

    canvas.on("object:moving", handleObjectMoving);
    canvas.on("object:scaling", handleObjectScaling);

    // Select actions
    canvas.on("selection:created", (e) => setSelectedObject(e.selected[0]));
    canvas.on("selection:updated", (e) => setSelectedObject(e.selected[0]));
    canvas.on("selection:cleared", () => setSelectedObject(null));

    // Change sync detectors
    const triggerSync = () => {
      // Recalculate price
      const stateDump = {};
      const views = ["front", "back", "left", "right", "pocket", "hood"];
      views.forEach((v) => {
        // Collect current storage cache values
        const stored = localStorage.getItem(`tshirt-designer-${v}`);
        stateDump[v] = stored ? JSON.parse(stored) : [];
      });
      // Replace active view with current live objects
      stateDump[view] = canvas.getObjects().filter(o => o !== printAreaBox).map(o => o.toJSON());
      
      // Update cache
      localStorage.setItem(`tshirt-designer-${view}`, JSON.stringify(stateDump[view]));
      
      recalculatePrice(stateDump);
      manualSync?.(view);
    };

    // Debounced snapshot push to prevent overloading undo stack
    const pushStateSnapshot = canvasSyncManager.debounce(() => {
      const stateDump = {};
      ["front", "back", "left", "right", "pocket", "hood"].forEach((v) => {
        const stored = localStorage.getItem(`tshirt-designer-${v}`);
        stateDump[v] = stored ? JSON.parse(stored) : [];
      });
      stateDump[view] = canvas.getObjects().filter(o => o !== printAreaBox).map(o => o.toJSON());
      pushSnapshot(stateDump);
    }, 400);

    canvas.on("object:modified", () => {
      triggerSync();
      pushStateSnapshot();
    });
    canvas.on("object:added", (e) => {
      const obj = e.target;
      // Skip the print-area guide itself and center-alignment guide lines —
      // only real design objects (images, text, clipart) get constrained.
      if (obj && obj !== printAreaBox && obj.name !== "guide-line") {
        constrainToBox(obj);
        canvas.requestRenderAll();
        triggerSync();
        pushStateSnapshot();
      }
    });
    canvas.on("object:removed", (e) => {
      if (e.target !== printAreaBox) {
        triggerSync();
        pushStateSnapshot();
      }
    });

    // Drag-and-drop image handler
    const handleDragOver = (e) => e.preventDefault();
    const handleDrop = (e) => {
      e.preventDefault();
      if (!e.dataTransfer.files?.[0]) return;
      const file = e.dataTransfer.files[0];
      if (!file.type.startsWith("image/")) return;

      const reader = new FileReader();
      reader.onload = (event) => {
        const imgObj = new Image();
        imgObj.src = event.target.result;
        imgObj.onload = () => {
          const image = new fabric.Image(imgObj);
          image.scaleToWidth(150);
          image.set({
            left: boxLeft + (boxSize - 150) / 2,
            top: boxTop + (boxSize - image.getScaledHeight()) / 2,
          });
          canvas.add(image);
          canvas.setActiveObject(image);
          canvas.renderAll();
        };
      };
      reader.readAsDataURL(file);
    };

    const containerEl = containerRef.current;
    containerEl.addEventListener("dragover", handleDragOver);
    containerEl.addEventListener("drop", handleDrop);

    // Initial baseline sync
    setTimeout(triggerSync, 200);

    return () => {
      containerEl.removeEventListener("dragover", handleDragOver);
      containerEl.removeEventListener("drop", handleDrop);
      canvas.off("object:moving", handleObjectMoving);
      canvas.off("object:scaling", handleObjectScaling);
      canvas.dispose();
      fabricCanvasRef.current = null;
      if (view === "front") setFrontCanvas(null);
      if (view === "back") setBackCanvas(null);
      if (view === "left") setLeftCanvas(null);
      if (view === "right") setRightCanvas(null);
      if (view === "pocket") setPocketCanvas(null);
      if (view === "hood") setHoodCanvas(null);
    };
  }, [view, printArea.width, printArea.height]);

  // Keep the shared "active canvas" in sync with whichever tab is actually
  // selected. Runs on mount AND whenever the user switches tabs, which is
  // what makes uploads/text additions land on the correct view instead of
  // whichever view's init effect happened to fire last.
  useEffect(() => {
    if (isSelected && fabricCanvasRef.current) {
      setActiveCanvas(fabricCanvasRef.current);
    }
  }, [isSelected]);

  // Handle center alignment guides (Center lines)
  const drawCenterGuides = () => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    // Remove old lines if any
    const existing = canvas.getObjects().filter(o => o.name === "guide-line");
    existing.forEach(o => canvas.remove(o));

    const guideStyle = {
      stroke: "#c084fc", // Purple-400
      strokeWidth: 1,
      strokeDashArray: [4, 4],
      selectable: false,
      evented: false,
      name: "guide-line",
      excludeFromExport: true,
    };

    // Guides are drawn across the square design box, not the full canvas
    const vert = new fabric.Line([boxLeft + boxSize / 2, boxTop, boxLeft + boxSize / 2, boxTop + boxSize], guideStyle);
    const horiz = new fabric.Line([boxLeft, boxTop + boxSize / 2, boxLeft + boxSize, boxTop + boxSize / 2], guideStyle);

    canvas.add(vert, horiz);
    canvas.renderAll();

    // Auto-remove center guide lines after 2.5 seconds
    setTimeout(() => {
      canvas.remove(vert, horiz);
      canvas.renderAll();
    }, 2500);
  };

  return (
    <div 
      ref={containerRef}
      className="relative flex flex-col items-center bg-white rounded-2xl border border-slate-200/80 shadow-sm p-4 select-none"
    >
      {/* Top Controls Toolbar */}
      <div className="w-full flex items-center justify-between border-b border-slate-100 pb-3.5 mb-4">
        <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
          <Compass className="h-4.5 w-4.5 text-amber-500" />
          {view.toUpperCase()} Workspace
        </span>
        <button
          onClick={drawCenterGuides}
          className="px-3 h-8 bg-slate-50 border border-slate-200 hover:border-violet-300 hover:bg-violet-50 text-slate-600 hover:text-violet-600 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors active:scale-95 cursor-pointer"
        >
          <Maximize className="h-3.5 w-3.5" /> Center Alignment Lines
        </button>
      </div>

      {/* Grid underlay background toggle */}
      <div 
        className="relative overflow-hidden border border-slate-200 rounded-xl"
        style={{
          width: `${canvasWidth}px`,
          height: `${canvasHeight}px`,
          transform: `scale(${canvasZoom})`,
          transformOrigin: "center top",
          transition: "transform 0.2s ease-out",
        }}
      >
        {/* Horizontal Ruler */}
        {rulersVisible && (
          <div className="absolute top-0 left-[24px] right-0 h-[24px] z-20">
            <CanvasRuler orientation="horizontal" length={canvasWidth} zoom={canvasZoom} />
          </div>
        )}

        {/* Vertical Ruler */}
        {rulersVisible && (
          <div className="absolute top-[24px] left-0 bottom-0 w-[24px] z-20">
            <CanvasRuler orientation="vertical" length={canvasHeight} zoom={canvasZoom} />
          </div>
        )}

        {/* Dynamic Grid Dot Background */}
        <div 
          className={`absolute inset-0 z-0 pointer-events-none transition-opacity ${
            gridVisible ? "opacity-100" : "opacity-0"
          }`}
          style={{
            backgroundImage: "radial-gradient(#cbd5e1 1.2px, transparent 1.2px)",
            backgroundSize: "20px 20px",
            backgroundColor: "#fafafa",
          }}
        />

        {/* Garment silhouette background (behind the design canvas) */}
        <GarmentSilhouette product={currentProduct} view={view} width={canvasWidth} height={canvasHeight} />

        <canvas
          ref={canvasRef}
          className="relative z-10 block"
        />
      </div>
    </div>
  );
}

export default function CanvasEditor({ manualSync }) {
  const currentProduct = useCustomizerStore((state) => state.currentProduct);
  const selectedView = useCustomizerStore((state) => state.selectedView);
  const setSelectedView = useCustomizerStore((state) => state.setSelectedView);
  
  const gridVisible = useCustomizerStore((state) => state.gridVisible);
  const setGridVisible = useCustomizerStore((state) => state.setGridVisible);
  const rulersVisible = useCustomizerStore((state) => state.rulersVisible);
  const setRulersVisible = useCustomizerStore((state) => state.setRulersVisible);
  const canvasZoom = useCustomizerStore((state) => state.canvasZoom);
  const setCanvasZoom = useCustomizerStore((state) => state.setCanvasZoom);

  // If currentProduct doesn't match a key in apparelConfig exactly, this
  // silently falls back to the tee layout — which looks like the canvas
  // "randomly" reverting to a t-shirt even when a different product (e.g.
  // Sports Jersey) is selected in the sidebar. That's almost always caused
  // by a naming/casing mismatch between the store's currentProduct value
  // and apparelConfig's keys, or currentProduct being briefly undefined
  // during a store update. Logging here makes the mismatch visible instead
  // of silently masking it.
  if (currentProduct && !apparelConfig[currentProduct]) {
    console.warn(
      `[CanvasEditor] currentProduct "${currentProduct}" has no matching entry in apparelConfig. ` +
      `Falling back to "half-sleeve". Check that apparelConfig's keys match the store's product identifiers exactly.`
    );
  }
  const productConfig = apparelConfig[currentProduct] || apparelConfig["half-sleeve"];

  return (
    <div className="flex flex-col gap-4 w-full h-full min-h-[500px]" key={currentProduct}>
      
      {/* Workspace Display PreferencesHUD */}
      <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200/60 rounded-xl">
        {/* Toggle Grid & Rulers */}
        <div className="flex gap-2">
          <button
            onClick={() => setGridVisible(!gridVisible)}
            className={`h-8 px-3 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              gridVisible 
                ? "bg-violet-600 border-violet-600 text-white" 
                : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
            }`}
          >
            <Grid className="h-3.5 w-3.5" /> Grid Lines
          </button>
          <button
            onClick={() => setRulersVisible(!rulersVisible)}
            className={`h-8 px-3 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              rulersVisible 
                ? "bg-violet-600 border-violet-600 text-white" 
                : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
            }`}
          >
            <Maximize className="h-3.5 w-3.5" /> Coordinate Rulers
          </button>
        </div>

        {/* Zoom Slider */}
        <div className="flex items-center gap-2">
          <ZoomOut className="h-3.5 w-3.5 text-slate-400" />
          <input
            type="range"
            min="0.5"
            max="1.5"
            step="0.05"
            value={canvasZoom}
            onChange={(e) => setCanvasZoom(parseFloat(e.target.value))}
            className="w-24 accent-violet-600 cursor-pointer"
          />
          <ZoomIn className="h-3.5 w-3.5 text-slate-400" />
          <span className="text-xs font-bold text-slate-500 w-8 text-right">
            {Math.round(canvasZoom * 100)}%
          </span>
        </div>
      </div>

      {/* Aspect Switcher tabs for active product */}
      <div className="flex gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-200/50 w-fit">
        {productConfig.supportedViews.map((viewKey) => (
          <button
            key={viewKey}
            onClick={() => setSelectedView(viewKey)}
            className={`px-4 h-8 rounded-lg text-xs font-bold uppercase tracking-wide transition-all cursor-pointer ${
              selectedView === viewKey
                ? "bg-slate-900 text-white shadow-sm"
                : "text-slate-600 hover:bg-slate-200 hover:text-slate-900"
            }`}
          >
            {viewKey}
          </button>
        ))}
      </div>

      {/* Display active view canvas and hide inactive views */}
      <div className="flex-1 w-full overflow-hidden">
        {productConfig.supportedViews.map((viewKey) => {
          const isSelected = selectedView === viewKey;
          const printArea = productConfig.printAreas[viewKey] || { width: 600, height: 800 };

          return (
            <div 
              key={`${currentProduct}-${viewKey}`} 
              className={`w-full ${isSelected ? "block animate-in fade-in duration-200" : "hidden"}`}
            >
              <SingleCanvasViewport 
                key={`${currentProduct}-${viewKey}`}
                view={viewKey} 
                printArea={printArea} 
                manualSync={manualSync} 
                isSelected={isSelected}
                currentProduct={currentProduct}
              />
            </div>
          );
        })}
      </div>
      
    </div>
  );
}