import React from "react";
import { useCustomizerStore } from "../store/useCustomizerStore";
import { apparelConfig } from "../utils/apparelConfig";
import { Shirt } from "lucide-react";
import { useCanvas } from "../context/CanvasContext";

export default function ProductSelector() {
  const currentProduct = useCustomizerStore((state) => state.currentProduct);
  const setCurrentProduct = useCustomizerStore((state) => state.setCurrentProduct);
  const { resetCanvases } = useCanvas();

  return (
    <div className="space-y-2">
      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Select Product</div>
      <div className="grid grid-cols-1 gap-2">
        {Object.entries(apparelConfig).map(([key, config]) => {
          const isSelected = currentProduct === key;
          return (
            <button
              key={key}
              onClick={() => {
                if (key !== currentProduct) {
                  resetCanvases();
                  setCurrentProduct(key);
                }
              }}
              className={`flex items-center justify-between p-3 rounded-xl border text-left transition-all duration-200 cursor-pointer ${
                isSelected
                  ? "bg-slate-900 border-slate-900 text-white shadow-md scale-[1.02]"
                  : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300"
              }`}
            >
              <div className="flex items-center gap-2">
                <Shirt className={`h-4.5 w-4.5 ${isSelected ? "text-amber-400" : "text-slate-400"}`} />
                <span className="text-xs font-bold">{config.name}</span>
              </div>
              <span className={`text-[10px] font-bold ${isSelected ? "text-amber-300" : "text-slate-400"}`}>
                ₹{config.basePrice}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
