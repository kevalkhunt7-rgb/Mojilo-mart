import React, { useRef, useState } from "react";
import * as fabric from "fabric";
import { useCanvas } from "../context/CanvasContext";
import { Upload, ImagePlus, Trash2, X } from "lucide-react";

export default function ImageUploadPanel() {
  const { activeCanvas } = useCanvas();
  const fileInputRef = useRef(null);
  const [uploads, setUploads] = useState([]); // { id, thumbnail, name }

  const handleFileSelect = (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;

    files.forEach((file) => {
      if (!file.type.startsWith("image/")) return;

      const reader = new FileReader();
      reader.onload = (event) => {
        const dataUrl = event.target.result;

        // Add to gallery
        setUploads((prev) => [
          ...prev,
          { id: Date.now() + Math.random(), thumbnail: dataUrl, name: file.name },
        ]);
      };
      reader.readAsDataURL(file);
    });

    // Reset so the same file can be re-selected
    e.target.value = "";
  };

  const handleAddToCanvas = (dataUrl) => {
    if (!activeCanvas) return;

    const imgEl = new Image();
    imgEl.crossOrigin = "anonymous";
    imgEl.src = dataUrl;

    imgEl.onload = () => {
      const fabricImg = new fabric.Image(imgEl, {
        left: activeCanvas.width / 2,
        top: activeCanvas.height / 2,
        originX: "center",
        originY: "center",
      });

      // Scale to a sensible default width
      fabricImg.scaleToWidth(Math.min(180, activeCanvas.width * 0.4));

      activeCanvas.add(fabricImg);
      activeCanvas.setActiveObject(fabricImg);
      activeCanvas.renderAll();
      activeCanvas.fire("object:modified");
    };
  };

  const handleRemoveUpload = (id) => {
    setUploads((prev) => prev.filter((u) => u.id !== id));
  };

  return (
    <div className="space-y-4">
      <div className="space-y-1">
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
          Image Upload
        </p>
        <p className="text-[11px] text-slate-500 leading-normal">
          Upload images from your device and place them onto your design canvas.
          Supports PNG, JPG, SVG, and WEBP.
        </p>
      </div>

      {/* Upload button */}
      <input
        type="file"
        accept="image/*"
        multiple
        ref={fileInputRef}
        onChange={handleFileSelect}
        className="hidden"
      />
      <button
        onClick={() => fileInputRef.current?.click()}
        className="w-full h-12 border-2 border-dashed border-slate-300 hover:border-violet-400 rounded-xl flex items-center justify-center gap-2 text-xs font-semibold text-slate-500 hover:text-violet-600 transition-colors cursor-pointer bg-slate-50/50 hover:bg-violet-50/30"
      >
        <Upload className="h-4 w-4" />
        Click to Upload Images
      </button>

      {/* Uploaded gallery */}
      {uploads.length > 0 && (
        <div className="space-y-2">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            Your Uploads ({uploads.length})
          </div>
          <div className="grid grid-cols-2 gap-2">
            {uploads.map((item) => (
              <div
                key={item.id}
                className="group relative bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow"
              >
                {/* Thumbnail */}
                <div className="aspect-square flex items-center justify-center p-2 bg-slate-50">
                  <img
                    src={item.thumbnail}
                    alt={item.name}
                    className="max-w-full max-h-full object-contain"
                  />
                </div>

                {/* Hover overlay */}
                <div className="absolute inset-0 bg-slate-900/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <button
                    onClick={() => handleAddToCanvas(item.thumbnail)}
                    className="w-8 h-8 rounded-lg bg-violet-600 text-white flex items-center justify-center hover:bg-violet-700 transition-colors cursor-pointer"
                    title="Add to canvas"
                  >
                    <ImagePlus className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => handleRemoveUpload(item.id)}
                    className="w-8 h-8 rounded-lg bg-red-500 text-white flex items-center justify-center hover:bg-red-600 transition-colors cursor-pointer"
                    title="Remove"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>

                {/* File name */}
                <div className="px-2 py-1.5 border-t border-slate-100">
                  <p className="text-[10px] font-semibold text-slate-500 truncate">
                    {item.name}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Empty state */}
      {uploads.length === 0 && (
        <div className="p-6 text-center">
          <ImagePlus className="h-8 w-8 text-slate-300 mx-auto mb-2" />
          <p className="text-[11px] text-slate-400 font-medium">
            No images uploaded yet. Click the button above to add your custom
            artwork, logos, or photos.
          </p>
        </div>
      )}
    </div>
  );
}
